package com.students.jaxrs.service;

import java.util.Collection;

import com.students.jaxrs.model.Student;

public interface StudentService {
	
	Collection<Student> getAllStudents();
	
	Student getById(Long id);

}
