package com.students.jaxrs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootJaxrsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootJaxrsApplication.class, args);
	}

}
