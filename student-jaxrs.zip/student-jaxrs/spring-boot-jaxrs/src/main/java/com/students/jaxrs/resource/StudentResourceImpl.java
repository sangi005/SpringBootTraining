package com.students.jaxrs.resource;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.students.jaxrs.model.Student;
import com.students.jaxrs.service.StudentService;

@Controller
public class StudentResourceImpl implements StudentResource {

	@Autowired
	private StudentService studentService;

	@Override
	public Collection<Student> getAllStudents() {
		return studentService.getAllStudents();
	}

	@Override
	public Student getById(Long id) {
		return studentService.getById(id);
	}
		
}
