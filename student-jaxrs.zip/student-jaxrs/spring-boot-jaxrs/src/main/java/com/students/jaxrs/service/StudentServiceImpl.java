package com.students.jaxrs.service;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.students.jaxrs.model.Student;
import com.students.jaxrs.repository.StudentRepository;

@Service
public class StudentServiceImpl implements StudentService {
	
	@Autowired
	private StudentRepository repository;
	
	@Override
	public Collection<Student> getAllStudents() {
		return repository.findAll();
	}

	@Override
	public Student getById(Long id) {
		return repository.findById(id);
	}

}
